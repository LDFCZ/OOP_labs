package ru.nsu.ccfit.lopatkin.client.utils;

public interface TimeOutHandler {
    void handle();
}
