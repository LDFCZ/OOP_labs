package ru.nsu.ccfit.lopatkin.client.exceptions;

public class SocketSendMessageException extends Exception{

    public SocketSendMessageException(String message) {
        super(message);
    }
}
