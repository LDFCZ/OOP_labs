package ru.nsu.ccfit.lopatkin.server.exceptions;

public class FindUserException extends Exception {
    public FindUserException(String message) {
        super(message);
    }
}
