package ru.nsu.ccfit.lopatkin.server.exceptions;

public class SaveUserException extends Exception{
    public SaveUserException(String message) {
        super(message);
    }
}
