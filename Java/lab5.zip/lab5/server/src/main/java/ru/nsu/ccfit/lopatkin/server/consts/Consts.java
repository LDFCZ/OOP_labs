package ru.nsu.ccfit.lopatkin.server.consts;

public class Consts {
    public static final String PATTERN = "dd/MM/yyyy HH:mm:ss";
}
